const TableCell = ({ cell}) => {
    return cell.render('Cell');
  // }
};

export default TableCell;
