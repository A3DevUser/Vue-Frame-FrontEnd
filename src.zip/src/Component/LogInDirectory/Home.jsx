import React from 'react'
import ChartComp from '../ChartDir/Chart ';

const Home = () => {
    return (
        <>
            <ChartComp />
        </>
    )
}

export default Home;