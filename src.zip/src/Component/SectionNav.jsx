import React from 'react'

const SectionNav = (subSectionData) => {
  return (
<>
<div className='d-flex flex-column align-items-start flex' >
<button type="button" class="btn btn-outline-primary m-2">Primary</button>
<button type="button" class="btn btn-outline-primary mx-5 my-1">Primary</button>
</div>
</>
  )
}

export default SectionNav
