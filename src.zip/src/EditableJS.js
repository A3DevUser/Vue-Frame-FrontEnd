export const EditableObj = {
    logerFunc : (val) =>{
        // console.log(val)
    }
}